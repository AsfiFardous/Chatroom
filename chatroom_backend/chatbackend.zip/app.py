import os

from flask import Flask, request, session, jsonify

#  session
from flask_session import Session
from flask_socketio import SocketIO, emit
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from flask_sqlalchemy import SQLAlchemy
import model
import json

app = Flask(__name__)

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


app.config["SECRET_KEY"] = os.getenv("SECRET_KEY")
socketio = SocketIO(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:1234@localhost/chatroom'


model.db.init_app(app)
# db = SQLAlchemy(app)


@app.route("/signin",  methods=["POST"])
def signin():
    jsondata = request.get_json()
    # print (jsondata)
    username = jsondata["username"]
    password = jsondata["password"]

    user = model.User.query.filter_by(
        username=username, password=password).first()

    print(user)
    if user is None:
        return jsonify('wrong user')
    else:
        user_schema = model.UserSchema()
        user_data = user_schema.dump(user)
        channel_schema = model.ChannelSchema()
        user_data['channels'] = [channel_schema.dump(c) for c in user.channels]
        session["username"] = user_data['username']
        print(user_data)
        user_dict = {
            'user_id': user_data['user_id'],
            'username': user_data['username'],
            'email': user_data['email'],
            'channels': user_data['channels']
        }

        return jsonify(user_dict)


@app.route("/signup",  methods=["POST"])
def signup():
    jsondata = request.get_json()
    username = jsondata["username"]
    password = jsondata["password"]
    email = jsondata["email"]
    print(jsondata)
    try:
        me = model.User(username=username, email=email, password=password)
        model.db.session.add(me)
        model.db.session.commit()
        return jsonify('saved')

    except Exception:
        return jsonify('Not saved')


@app.route("/add-channel", methods=["POST"])
def addchannel():
    jsondata = request.get_json()
    user_id = jsondata["user_id"]
    channel = jsondata["newChannel"]
    print(jsondata)
    try:
        user = model.User.query.filter_by(user_id=user_id).first()
        print(user)
        me = model.Channel(users=[user, ], channel_name=channel)
        model.db.session.add(me)
        model.db.session.commit()
        user = model.User.query.filter_by(user_id=user_id).first()
        print(user)
        user_schema = model.UserSchema()
        user_data = user_schema.dump(user)
        channel_schema = model.ChannelSchema()
        user_data['channels'] = [channel_schema.dump(c) for c in user.channels]
        user_dict = {
            'channels': user_data['channels']
        }
        return jsonify(user_dict)

    except Exception as e:
        # print(e)
        return jsonify('Not saved')


@app.route("/get-channel-details/<user_id>/<channel_id>",  methods=["GET"])
def getchanneldetails(user_id, channel_id):
    try:
        channel = model.Channel.query.filter_by(
            channel_id=channel_id, user_id=user_id).first()
        if channel is None:
            return jsonify('Excess denied')
        else:
            channel_schema = model.ChannelSchema()
            channel_data = user_schema.dump(channel)
            user_schema = model.UserSchema()
            channel_data['users'] = [
                user_schema.dump(c) for c in channel.users]
            message_schema = model.MessageSchema()
            channel_data['messages'] = [
                message_schema.dump(c) for c in channel.messages]
            channel_dict = {
                # 'channel_name': channel_data['channel_name'],
                'users': channel_data['users']
                'messages': channel_data['messages']
            }
            return jsonify(channel_dict)

    except Exception:
        return jsonify('Failed to get channel details')


#  @app.route("//get-channel-messages/<channel_id>",  methods=["GET"])
# def getchannelmessages(channel_id):
#     try:
#         channel = model.Channel.query.filter_by(channel_id=channel_id).first()
#         if channel is None:
#             return jsonify('Excess denied')
#         else:
#             channel_schema = model.ChannelSchema()
#             channel_data = user_schema.dump(channel)
#             user_schema = model.UserSchema()
#             channel_data['users'] = [user_schema.dump(c) for c in channel.users]
#             channel_dict={
#                 # 'channel_name': channel_data['channel_name'],
#                 'users': channel_data['users']
#             }
#             return jsonify(channel_dict)

#     except Exception:
#          return jsonify('Failed to get channel details')
@socketio.on("submit message")
def message(data):
    message = data["message"]
    user_id = data["user_id"]
    channel_id = data["channel_id"]
    channel = model.Channel.query.filter_by(
        channel_id=channel_id, user_id=user_id).first()
       if channel is None:
            return jsonify('Excess denied')
        else:
            try:
                me = model.Message(message_body = message, user_id = user_id,channel_id = channel_id)
                model.db.session.add(me)
                model.db.session.commit()
                emit(channel_id, {"message": message, "user_id": user_id}, broadcast=True)
            except Exception:
                return jsonify('Message sending failed')


# @app.route("/addChannel",  methods=["POST"])
# def sign_up(usename,email,password):

#     me = User(username, email, password)
#     db.session.add(me)
#     db.session.commit()

#     return True
