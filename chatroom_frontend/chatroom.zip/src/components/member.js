import React, { Component } from "react";
import { urlget } from '../utils/fetch-helper';
import { urlpost } from '../utils/fetch-helper';
import {
    Link, useHistory
} from "react-router-dom";

export default class Home extends Component {
    constructor(props) {
        super(props);

    }


    render() {
        return (

            <div>
               <h1>Hi {this.props.match.params.id}</h1>
            </div>


        )
    }
}