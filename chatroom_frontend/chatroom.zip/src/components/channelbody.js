import React, { Component } from "react";
import { urlget } from '../utils/fetch-helper';
import { urlpost } from '../utils/fetch-helper';
import {
    Link, useHistory
} from "react-router-dom";

var socket = io.connect(location.protocol + '//' + document.domain + ':' + location.port);
socket.on('connect', () => {
    var listOfMessages = [];

});
export default class Channelbody extends Component {
    constructor(props) {
        super(props);
        this.state = {
            channel_id: this.props.channel_id,
            new_message: null,
        };

        // let getChannelMessagePromise = urlget('/get-channel-messages', this.state.channel_id)
        // getChannelMessagePromise.then(function (abcd) { return abcd.json() })
        //     .then(jsonResponse => {
        //         console.log(jsonResponse);
        //         if (jsonResponse !== 'Excess denied' || jsonResponse !== 'Failed to get channel details') {
        //             this.setState({
        //                 channel_members: jsonResponse.users
        //             })
        //         }
        //         else {
        //             alert('Unsuccessful! Please try again')
        //         }
        //     })

        //     .catch(function (error) {
        //         console.log(error);
        //     });
        // When a new vote is announced, add to the unordered list
        socket.on(this.state.channel_id, data => {
            li.innerHTML = `Vote recorded: ${data.selection}1`;
            document.querySelector('#votes').append(li);
        });
    }
  

    handleClickSend(evt) {
        evt.preventDefault();
        socket.emit('submit message', {'message': message,'user_id': localStorage.getItem('user_id') ,'channel_id': this.state.channels.channel_id});
    }

    handleChange(event) {
        this.setState({ new_message: event.target.value })
    }

    render() {
        return (
            <div className="chatWindow">
                <ul className="chat" id="chatList">
                    {this.state.groupMessage.map(data => (
                        <div key={data.id}>
                            {this.state.user.uid === data.sender.uid ? (
                                <li className="self">
                                    <div className="msg">
                                        <p>{data.sender.uid}</p>
                                        <div className="message"> {data.data.text}</div>
                                    </div>
                                </li>
                            ) : (
                                    <li className="other">
                                        <div className="msg">
                                            <p>{data.sender.uid}</p>
                                            <div className="message"> {data.data.text} </div>
                                        </div>
                                    </li>
                                )}
                        </div>
                    ))}
                </ul>
                <div className="chatInputWrapper">
                    <form >
                        <input
                            className="textarea input"
                            type="text"
                            placeholder="Enter your message..."
                            value={this.state.message} onChange={this.handleChange}
                        />
                        <button type="submit" className="btn btn-primary btn-block" onClick={this.handleClickSend.bind(this)}>Send</button>
                    </form>
                </div>
            </div>
        );
    }
        
        }
    