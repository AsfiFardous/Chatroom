import React, { Component } from "react";
import { urlget } from '../utils/fetch-helper';
import { urlpost } from '../utils/fetch-helper';
import {
    Link, useHistory
} from "react-router-dom";
import Channelbody from "./channelbody";

export default class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            channel_id: this.props.channel.channel_id,
            channel_members: null
        };
        let params = {
            'user_id': localStorage.getItem('user_id'),
            'channel_id': this.state.channel_id
        };

        let getChannelDetailsPromise = urlget('/get-channel-details', params)
        getChannelDetailsPromise.then(function (abcd) { return abcd.json() })

            .then(jsonResponse => {
                console.log(jsonResponse);
                if (jsonResponse !== 'Excess denied' || jsonResponse !== 'Failed to get channel details') {
                    this.setState({
                        channel_members: jsonResponse.users,
                        messages: jsonResponse.messages
                    })
                }
                else {
                    alert('Unsuccessful! Please try again')
                }
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    render() {
        return (
            <div>
                < Channelbody channel_id = {this.state.channel_id} channel_members={this.state.channel_members}  messages= {this.state.messages}/>
            </div>
        )
    }
}